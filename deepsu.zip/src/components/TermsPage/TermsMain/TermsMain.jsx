import styles from "./TermsMain.module.scss";

const TermsMain = () => {
  return (
    <>
      <section className={styles.aboutMain}></section>
    </>
  );
};

export default TermsMain;
