import React from "react";
import HomeMain from "../components/HomePage/HomeMain/HomeMain";

const HomePage = () => {
  return (
    <>
      <HomeMain />
    </>
  );
};

export default HomePage;