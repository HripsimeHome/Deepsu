import React from "react";
import TermsMain from "../components/TermsPage/TermsMain/TermsMain";

const TermsPage = () => {
  return (
    <>
      <TermsMain />
    </>
  );
};

export default TermsPage;
