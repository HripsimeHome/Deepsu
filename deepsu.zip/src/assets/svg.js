
// Header
export const docIcon = "doc"; 
export const telegramIcon = "telegram";  
export const twitterIcon = "twitter"; 
