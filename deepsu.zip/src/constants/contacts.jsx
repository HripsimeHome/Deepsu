export const twitterUrl = "https://x.com";
export const telegramUrl = "https://web.telegram.org";
export const emailAddress = "info@deepsu.ai1";
export const documentation = "https://deepsuai.gitbook.io/whitepaper"